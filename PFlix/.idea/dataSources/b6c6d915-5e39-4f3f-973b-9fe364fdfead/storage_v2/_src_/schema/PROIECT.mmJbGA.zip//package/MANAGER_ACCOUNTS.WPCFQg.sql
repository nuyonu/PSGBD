create PACKAGE manager_accounts IS
  PROCEDURE add_user(p_username IN VARCHAR2, p_password IN VARCHAR2, p_e_mail VARCHAR2, p_rank CHAR, p_birth_date DATE,
                     p_origin_country VARCHAR2);
  PROCEDURE delete_user(p_username IN users.username%TYPE);

  FUNCTION username_already_exists(p_username IN VARCHAR2) RETURN BOOLEAN;
  FUNCTION email_already_exists(p_email IN VARCHAR2) RETURN BOOLEAN;
  FUNCTION login(p_username IN VARCHAR2, p_password IN VARCHAR2) RETURN BOOLEAN;
END manager_accounts;
/

