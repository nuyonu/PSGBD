create trigger ID_RATING_REVIEW_A_INCREMENT
    before insert
    on RATING_REVIEW
    for each row
BEGIN
  SELECT seq_id_rating_review_icrmt.NEXTVAL
  INTO   :new.id
  FROM   dual;
END;
/

