create trigger ID_LISTS_A_INCREMENT
    before insert
    on LISTS
    for each row
BEGIN
  SELECT seq_id_lists_icrmt.NEXTVAL
  INTO   :new.id
  FROM   dual;
END;
/

