create trigger MOVIE_LIST_UPDATE_UPDT_AT
    before update
    on MOVIE_LIST
    for each row
BEGIN
   SELECT CURRENT_DATE
   INTO :NEW.updated_at
   FROM dual;
END;
/

