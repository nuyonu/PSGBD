create trigger ID_REVIEWS_A_INCREMENT
    before insert
    on REVIEWS
    for each row
BEGIN
  SELECT seq_id_reviews_icrmt.NEXTVAL
  INTO   :new.id
  FROM   dual;
END;
/

