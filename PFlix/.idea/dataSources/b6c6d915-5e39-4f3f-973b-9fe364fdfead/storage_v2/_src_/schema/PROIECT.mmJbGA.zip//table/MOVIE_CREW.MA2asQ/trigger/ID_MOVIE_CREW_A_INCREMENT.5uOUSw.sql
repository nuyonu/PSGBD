create trigger ID_MOVIE_CREW_A_INCREMENT
    before insert
    on MOVIE_CREW
    for each row
BEGIN
  SELECT seq_id_movie_crew_icrmt.NEXTVAL
  INTO   :new.id
  FROM   dual;
END;
/

