create PROCEDURE populate_roles_table AS
    TYPE roless IS VARRAY(50) OF VARCHAR2(50);

    v_role roles.role%TYPE; --varchar2(50)

    v_roles roless := roless('Director', 'Writer', 'Story Editor', 'Dialogue Coach', 'Location Manager', 'Set Designer', 'Art Director', 'Costume Designer', 'Unit Production Manager', 'Line Producer', 'Production Manager', 'Assistant Director', 'Second Assistant Director', 'Continuity Person', 'Cinematographer', 'Gaffer', 'Camera Operator', 'Assistant Cameraman', 'Film Loader', 'Steadicam Operator', 'Production Sound Mixer', 'Boom Operator', 'Actor', 'Key Grip', 'Dolly Grip', 'Best Boy', 'Visual Effects Director', 'FX Coordinator', 'Property Master', 'Leadman', 'Costumer', 'Make-up Artist', 'Body Make-up Artist', 'Hairdresser', 'Unit Publicist', 'Production Caterer', 'Post-Production Supervisor', 'Editor', 'Color Timer', 'Negative Cutter', 'Music Mixer', 'Matte Artist');

BEGIN
    FOR v_index IN 1..v_roles.COUNT LOOP
        INSERT INTO roles (role) VALUES (v_roles(v_index));
    END LOOP;
END;
/

