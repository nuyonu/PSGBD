create trigger ID_MOVIE_LIST_A_INCREMENT
    before insert
    on MOVIE_LIST
    for each row
BEGIN
  SELECT seq_id_movie_list_icrmt.NEXTVAL
  INTO   :new.id
  FROM   dual;
END;
/

