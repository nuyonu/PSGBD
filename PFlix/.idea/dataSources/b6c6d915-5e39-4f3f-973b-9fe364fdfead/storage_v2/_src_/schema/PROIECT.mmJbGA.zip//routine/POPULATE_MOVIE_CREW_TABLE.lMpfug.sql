create PROCEDURE populate_movie_crew_table AS
    v_total_people NUMBER;
    v_first_id_people NUMBER;
    v_total_roles NUMBER;
    v_first_id_role NUMBER;
    v_total_team_members NUMBER;
BEGIN
    SELECT COUNT(*) INTO v_total_people FROM people;
    SELECT MIN(people.id) INTO v_first_id_people FROM people;
    SELECT COUNT(*) INTO v_total_roles FROM roles;
    SELECT MIN(roles.id) INTO v_first_id_role FROM roles;

    FOR v_movie IN (SELECT * FROM movies) LOOP
         v_total_team_members := ROUND(DBMS_RANDOM.VALUE(10, 100));
         FOR v_index IN 1..v_total_team_members LOOP
            INSERT INTO movie_crew (id_movie, id_person, id_role)
            VALUES (v_movie.id, TRUNC(DBMS_RANDOM.VALUE(v_first_id_people, v_first_id_people + v_total_people)), TRUNC(DBMS_RANDOM.VALUE(v_first_id_role, v_first_id_role + v_total_roles)));
         END LOOP;
    END LOOP;
END;
/

