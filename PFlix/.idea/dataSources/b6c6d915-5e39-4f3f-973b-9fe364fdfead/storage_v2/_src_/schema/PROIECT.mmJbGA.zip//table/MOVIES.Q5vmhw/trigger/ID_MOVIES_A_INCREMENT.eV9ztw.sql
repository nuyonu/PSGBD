create trigger ID_MOVIES_A_INCREMENT
    before insert
    on MOVIES
    for each row
BEGIN
  SELECT seq_id_movies_icrmt.NEXTVAL
  INTO   :new.id
  FROM   dual;
END;
/

