create FUNCTION generate_random_date(p_start_date IN DATE, p_end_date IN DATE)
RETURN DATE AS
BEGIN
    return TO_DATE(TRUNC(DBMS_RANDOM.VALUE(TO_CHAR(p_start_date, 'J'), TO_CHAR(p_end_date, 'J'))), 'J');
END;
/

