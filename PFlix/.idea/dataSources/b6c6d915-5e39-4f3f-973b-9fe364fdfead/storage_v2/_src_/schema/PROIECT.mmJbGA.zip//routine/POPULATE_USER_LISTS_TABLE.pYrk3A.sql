create PROCEDURE populate_user_lists_table AS
    v_total_users NUMBER;
    v_first_id_from_users NUMBER;
BEGIN
    SELECT COUNT(*) INTO v_total_users FROM users;
    SELECT MIN(users.id) INTO v_first_id_from_users FROM users;

    FOR v_list IN (SELECT * FROM lists) LOOP
         INSERT INTO user_lists (id_user, id_list) 
         VALUES(TRUNC(DBMS_RANDOM.VALUE(v_first_id_from_users, v_first_id_from_users + v_total_users)), v_list.id);
    END LOOP;
END;
/

