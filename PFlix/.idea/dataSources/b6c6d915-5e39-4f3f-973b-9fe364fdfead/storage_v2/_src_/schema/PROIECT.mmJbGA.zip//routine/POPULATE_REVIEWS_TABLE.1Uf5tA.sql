create PROCEDURE populate_reviews_table(p_total_reviews IN NUMBER) AS
    TYPE titles_begin IS VARRAY(50) OF VARCHAR2(100);

    v_title reviews.title%TYPE; --VARCHAR2(100)
    v_description reviews.description%TYPE; --VARCHAR2(1000
    v_review_date reviews.review_date%TYPE; --DATE
    v_likes reviews.likes%TYPE; --NUMBER
    v_dislikes reviews.dislikes%TYPE; --NUMBER
    v_spoiler reviews.spoiler%TYPE; --NUMBER(1)

    title_begin titles_begin := titles_begin('able','bad','best','better','big','black','certain','clear','different','early','easy','economic','federal','free','full','good','great','hard','high','human','important','international','large','late','little','local','long','low','major','military','national','new','old','only','other','political','possible','public','real','recent','right','small','social','special','strong','sure','true','white','whole','young');

BEGIN
    FOR v_index IN 1..p_total_reviews LOOP
        v_title := title_begin(DBMS_RANDOM.VALUE(1, title_begin.COUNT)) || DBMS_RANDOM.STRING('A', 5);

        v_description := DBMS_RANDOM.STRING('A', 500);

        v_review_date := CURRENT_DATE - (TRUNC(DBMS_RANDOM.VALUE(0,11)) * 365);

        v_likes := TRUNC(DBMS_RANDOM.VALUE(0, 999999));

        v_dislikes := TRUNC(DBMS_RANDOM.VALUE(0, 9999));

        v_spoiler := ROUND(DBMS_RANDOM.VALUE(0, 1));

        INSERT INTO reviews (title, description, review_date, likes, dislikes, spoiler) 
        VALUES (v_title, v_description, v_review_date, v_likes, v_dislikes, v_spoiler);
    END LOOP;
END;
/

