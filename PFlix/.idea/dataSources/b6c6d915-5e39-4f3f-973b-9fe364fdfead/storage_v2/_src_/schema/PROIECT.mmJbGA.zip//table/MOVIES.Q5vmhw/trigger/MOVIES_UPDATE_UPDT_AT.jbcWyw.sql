create trigger MOVIES_UPDATE_UPDT_AT
    before update
    on MOVIES
    for each row
BEGIN
   SELECT CURRENT_DATE
   INTO :NEW.updated_at
   FROM dual;
END;
/

