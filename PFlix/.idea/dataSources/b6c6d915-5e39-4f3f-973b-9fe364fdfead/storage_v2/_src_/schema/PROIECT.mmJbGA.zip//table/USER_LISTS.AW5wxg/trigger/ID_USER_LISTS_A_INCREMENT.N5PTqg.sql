create trigger ID_USER_LISTS_A_INCREMENT
    before insert
    on USER_LISTS
    for each row
BEGIN
  SELECT seq_id_user_lists_icrmt.NEXTVAL
  INTO   :new.id
  FROM   dual;
END;
/

