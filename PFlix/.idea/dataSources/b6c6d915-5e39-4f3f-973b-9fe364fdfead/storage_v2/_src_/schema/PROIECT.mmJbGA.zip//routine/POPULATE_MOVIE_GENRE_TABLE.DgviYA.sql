create PROCEDURE populate_movie_genre_table AS
    v_totalGenres NUMBER;
    v_first_id_genres NUMBER;
    v_random_probability NUMBER;
BEGIN
    SELECT COUNT(*) INTO v_totalGenres FROM genres;
    SELECT MIN(genres.id) INTO v_first_id_genres FROM genres;

    FOR v_movie IN (SELECT * FROM movies) LOOP
        v_random_probability := DBMS_RANDOM.VALUE(0.01, 0.99);
        CASE
        WHEN v_random_probability <= 0.3 THEN
            INSERT INTO movie_genre (id_genre, id_movie) VALUES (TRUNC(DBMS_RANDOM.VALUE(v_first_id_genres, v_first_id_genres + v_totalGenres)), v_movie.id);
        WHEN v_random_probability <= 0.7 AND v_random_probability > 0.3  THEN
            INSERT INTO movie_genre (id_genre, id_movie) VALUES (TRUNC(DBMS_RANDOM.VALUE(v_first_id_genres, v_first_id_genres + v_totalGenres - v_totalGenres/2 - 1)), v_movie.id);
            INSERT INTO movie_genre (id_genre, id_movie) VALUES (TRUNC(DBMS_RANDOM.VALUE( v_first_id_genres + v_totalGenres - v_totalGenres/2, v_first_id_genres + v_totalGenres)), v_movie.id);
        ELSE 
            INSERT INTO movie_genre (id_genre, id_movie) VALUES (TRUNC(DBMS_RANDOM.VALUE(v_first_id_genres, v_first_id_genres + v_totalGenres - (v_totalGenres/3 * 2) - 1)), v_movie.id);
            INSERT INTO movie_genre (id_genre, id_movie) VALUES (TRUNC(DBMS_RANDOM.VALUE(v_first_id_genres + v_totalGenres - (v_totalGenres/3 * 2),v_first_id_genres + v_totalGenres - v_totalGenres/3 - 1)), v_movie.id);
            INSERT INTO movie_genre (id_genre, id_movie) VALUES (TRUNC(DBMS_RANDOM.VALUE(v_first_id_genres + v_totalGenres - v_totalGenres/3, v_first_id_genres + v_totalGenres)), v_movie.id);
        END CASE;
    END LOOP;
END;
/

