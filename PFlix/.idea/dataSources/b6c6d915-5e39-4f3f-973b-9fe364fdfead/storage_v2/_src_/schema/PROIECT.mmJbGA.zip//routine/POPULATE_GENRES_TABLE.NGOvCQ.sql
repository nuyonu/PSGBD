create PROCEDURE populate_genres_table AS
    TYPE genress IS VARRAY(100) OF VARCHAR2(25);

    v_genre genres.genre%TYPE; --varchar2(25)
    v_genres genress := genress('Aerospace ','Biography','Buddy Cop ','Burlesque ','Chick Flick','Circus ','Comedy ','Black comedy','Gross-out ','Romantic comedy ','Screwball comedy ','Wacky Comedy ','Stoner ','Coming-of-age s.','Comic Book -superhero','Concert ','Courtroom drama ','Current Events ','Detective ','Disaster ','Drama ','Romantic Drama ','Educational ','Ephemeral ','Exploitation ','Blaxploitation','Fantasy ','fantastique','Gangster ','Gay movies','Gothic ','Heist ','History ','Horror ','Slasher ','Jungle ','Martial arts ','Wu Xia ','Medieval ','Military ','Mountie ','Mystery ','Nature ','Police ','Politics ','Pornographic ','Prison ','Propaganda ','Psycho ','Religion ','Revolution ','Road movie','Romance ','Science ','Science fiction ','Sex ','Sitcom ','Social guidance ','Spiritual ','Sports ','Baseball ','Spy ','Sword and Sandal ','Teen ','Travelogue','Variety ','War ','Submarine ','Western');

BEGIN
    FOR v_index IN 1..v_genres.COUNT LOOP
        INSERT INTO genres (genre) VALUES (v_genres(v_index));
    END LOOP;
END;
/

