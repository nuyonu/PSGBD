create view TOP15_BY_RATING as
SeLeCt "TITLE","Rating" FROM (
SeLeCt movies.title, TRUNC(AVG(ratings.rating),1) "Rating" FROM movies
JOIN movie_ratings ON movies.id = movie_ratings.id_movie
JOIN ratings ON ratings.id = movie_ratings.id_rating
GROUP BY movies.title, movies.id
ORDER BY 2 DESC) WHERE ROWNUM <= 15
/

