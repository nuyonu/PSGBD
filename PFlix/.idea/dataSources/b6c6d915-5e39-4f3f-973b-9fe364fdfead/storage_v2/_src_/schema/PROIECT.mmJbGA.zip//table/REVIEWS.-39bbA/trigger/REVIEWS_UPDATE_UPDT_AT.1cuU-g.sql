create trigger REVIEWS_UPDATE_UPDT_AT
    before update
    on REVIEWS
    for each row
BEGIN
   SELECT CURRENT_DATE
   INTO :NEW.updated_at
   FROM dual;
END;
/

