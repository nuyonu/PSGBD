create PROCEDURE populate_lists_table(p_total_lists IN NUMBER) AS
BEGIN
    FOR v_index IN 1..p_total_lists LOOP
        INSERT INTO lists (creation_date) VALUES (CURRENT_DATE - (DBMS_RANDOM.VALUE(0, 10) * DBMS_RANDOM.VALUE(1, 365)));
    END LOOP;
END;
/

