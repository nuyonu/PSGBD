create trigger ID_RATINGS_A_INCREMENT
    before insert
    on RATINGS
    for each row
BEGIN
  SELECT seq_id_ratings_icrmt.NEXTVAL
  INTO   :NEW.ID
  FROM   dual;
END;
/

