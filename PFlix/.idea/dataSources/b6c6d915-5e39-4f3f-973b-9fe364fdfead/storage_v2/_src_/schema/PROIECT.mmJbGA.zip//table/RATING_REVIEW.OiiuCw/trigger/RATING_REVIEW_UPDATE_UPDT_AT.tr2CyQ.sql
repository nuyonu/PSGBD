create trigger RATING_REVIEW_UPDATE_UPDT_AT
    before update
    on RATING_REVIEW
    for each row
BEGIN
   SELECT CURRENT_DATE
   INTO :NEW.updated_at
   FROM dual;
END;
/

