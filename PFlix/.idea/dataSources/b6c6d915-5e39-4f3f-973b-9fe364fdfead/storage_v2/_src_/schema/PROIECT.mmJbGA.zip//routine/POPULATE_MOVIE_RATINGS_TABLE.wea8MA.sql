create PROCEDURE populate_movie_ratings_table AS
    v_total_movies NUMBER DEFAULT 0;
    v_first_id_from_movie NUMBER;
BEGIN
    SELECT COUNT(*) INTO v_total_movies FROM movies;
    SELECT MIN(movies.id) INTO v_first_id_from_movie FROM movies;

    FOR v_rating IN (SELECT * FROM ratings) LOOP
        INSERT INTO movie_ratings (id_rating, id_movie) 
        VALUES(v_rating.id, TRUNC(DBMS_RANDOM.VALUE(v_first_id_from_movie, v_first_id_from_movie + v_total_movies)));
    END LOOP;
END;
/

