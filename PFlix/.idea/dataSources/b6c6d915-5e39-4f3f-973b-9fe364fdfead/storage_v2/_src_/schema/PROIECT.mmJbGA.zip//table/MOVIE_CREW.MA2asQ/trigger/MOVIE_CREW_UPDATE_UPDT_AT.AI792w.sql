create trigger MOVIE_CREW_UPDATE_UPDT_AT
    before update
    on MOVIE_CREW
    for each row
BEGIN
   SELECT CURRENT_DATE
   INTO :NEW.updated_at
   FROM dual;
END;
/

