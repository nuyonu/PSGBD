create PROCEDURE populate_user_ratings_table AS
    v_totalUsers NUMBER DEFAULT 0;
    v_first_id_users NUMBER;
BEGIN
    SELECT COUNT(*) INTO v_totalUsers FROM users;
    SELECT MIN(users.id) INTO v_first_id_users FROM users;

    FOR v_rating IN (SELECT * FROM ratings) LOOP
        INSERT INTO user_ratings (id_user, id_rating) VALUES (TRUNC(DBMS_RANDOM.VALUE(v_first_id_users, v_first_id_users + v_totalUsers)), v_rating.id);
    END LOOP;
END;
/

