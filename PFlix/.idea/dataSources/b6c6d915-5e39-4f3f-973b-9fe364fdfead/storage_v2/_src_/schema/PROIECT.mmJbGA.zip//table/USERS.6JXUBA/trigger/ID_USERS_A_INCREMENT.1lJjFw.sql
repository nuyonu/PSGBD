create trigger ID_USERS_A_INCREMENT
    before insert
    on USERS
    for each row
BEGIN
  SELECT seq_id_users_icrmt.NEXTVAL
  INTO   :new.id
  FROM   dual;
END;
/

