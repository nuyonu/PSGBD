create trigger ID_PEOPLE_A_INCREMENT
    before insert
    on PEOPLE
    for each row
BEGIN
  SELECT seq_id_people_icrmt.NEXTVAL
  INTO   :new.id
  FROM   dual;
END;
/

