create trigger ROLES_UPDATE_UPDT_AT
    before update
    on ROLES
    for each row
BEGIN
   SELECT CURRENT_DATE
   INTO :NEW.updated_at
   FROM dual;
END;
/

