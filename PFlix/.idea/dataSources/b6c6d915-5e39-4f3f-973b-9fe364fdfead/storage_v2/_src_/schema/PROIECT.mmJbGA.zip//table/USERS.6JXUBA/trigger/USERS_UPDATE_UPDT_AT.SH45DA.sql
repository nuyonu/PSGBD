create trigger USERS_UPDATE_UPDT_AT
    before update
    on USERS
    for each row
BEGIN
   SELECT CURRENT_DATE
   INTO :NEW.updated_at
   FROM dual;
END;
/

