create trigger ID_MOVIE_GENRE_A_INCREMENT
    before insert
    on MOVIE_GENRE
    for each row
BEGIN
  SELECT seq_id_movie_genre_icrmt.NEXTVAL
  INTO   :new.id
  FROM   dual;
END;
/

