create PROCEDURE populate_ratings_table(p_total_ratings IN NUMBER) AS
BEGIN
    FOR v_index IN 1..p_total_ratings LOOP
        INSERT INTO ratings (rating) VALUES (ROUND(DBMS_RANDOM.VALUE(1, 10)));
    END LOOP;
END;
/

