create FUNCTION generate_random_movie_duration
RETURN movies.duration%TYPE AS
    v_days CHAR(1);
    v_hours NUMBER(2);
BEGIN
    IF (DBMS_RANDOM.value() < 0.001) THEN
        v_days := '1';
    ELSE
        v_days := '0';
    END IF;

    IF (DBMS_RANDOM.value() < 0.01) THEN
        v_hours := TRUNC(DBMS_RANDOM.value(3, 23));
    ELSE
        v_hours := TRUNC(DBMS_RANDOM.value(0, 3));
    END IF;

    return TO_DSINTERVAL(v_days || ' ' || 
                         v_hours || ':' ||
                         TO_CHAR(TRUNC(DBMS_RANDOM.value(0, 59))) || ':' ||
                         TO_CHAR(TRUNC(DBMS_RANDOM.value(0, 59))));
END;
/

