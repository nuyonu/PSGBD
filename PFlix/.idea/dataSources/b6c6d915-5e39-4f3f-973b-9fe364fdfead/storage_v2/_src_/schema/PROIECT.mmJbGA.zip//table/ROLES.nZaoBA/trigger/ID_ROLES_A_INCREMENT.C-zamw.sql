create trigger ID_ROLES_A_INCREMENT
    before insert
    on ROLES
    for each row
BEGIN
  SELECT seq_id_roles_icrmt.NEXTVAL
  INTO   :new.id
  FROM   dual;
END;
/

