create trigger ID_MOVIE_RATINGS_A_INCREMENT
    before insert
    on MOVIE_RATINGS
    for each row
BEGIN
  SELECT seq_id_movie_ratings_icrmt.NEXTVAL
  INTO   :new.id
  FROM   dual;
END;
/

