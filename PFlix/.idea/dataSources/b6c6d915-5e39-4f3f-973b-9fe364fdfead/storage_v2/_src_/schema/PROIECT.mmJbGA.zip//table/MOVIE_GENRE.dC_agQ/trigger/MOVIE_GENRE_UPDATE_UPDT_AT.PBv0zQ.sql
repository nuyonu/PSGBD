create trigger MOVIE_GENRE_UPDATE_UPDT_AT
    before update
    on MOVIE_GENRE
    for each row
BEGIN
   SELECT CURRENT_DATE
   INTO :NEW.updated_at
   FROM dual;
END;
/

