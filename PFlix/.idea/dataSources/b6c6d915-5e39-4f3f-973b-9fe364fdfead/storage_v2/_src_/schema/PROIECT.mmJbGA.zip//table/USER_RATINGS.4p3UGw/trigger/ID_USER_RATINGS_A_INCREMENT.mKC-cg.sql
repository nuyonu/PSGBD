create trigger ID_USER_RATINGS_A_INCREMENT
    before insert
    on USER_RATINGS
    for each row
BEGIN
  SELECT seq_id_user_ratings_icrmt.NEXTVAL
  INTO   :new.id
  FROM   dual;
END;
/

