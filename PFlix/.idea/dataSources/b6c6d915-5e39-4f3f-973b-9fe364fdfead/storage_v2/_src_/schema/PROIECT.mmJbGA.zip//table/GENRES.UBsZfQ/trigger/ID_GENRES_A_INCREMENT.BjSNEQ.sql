create trigger ID_GENRES_A_INCREMENT
    before insert
    on GENRES
    for each row
BEGIN
  SELECT seq_id_genres_icrmt.NEXTVAL
  INTO   :new.id
  FROM   dual;
END;
/

