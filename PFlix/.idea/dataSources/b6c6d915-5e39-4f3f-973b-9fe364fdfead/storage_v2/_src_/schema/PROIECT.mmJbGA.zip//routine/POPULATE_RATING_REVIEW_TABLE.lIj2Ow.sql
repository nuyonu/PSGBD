create PROCEDURE populate_rating_review_table AS
    v_id_rating NUMBER := 1;
BEGIN
    FOR v_review IN (SELECT * FROM reviews) LOOP
        INSERT INTO rating_review (id_rating, id_review) VALUES (v_id_rating, v_review.id);
        v_id_rating := v_id_rating + 1;
    END LOOP;
END;
/

