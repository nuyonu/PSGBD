create trigger CHECK_AGE_THRESHOLD
    before insert or update
    on USERS
    for each row
BEGIN
  IF (TRUNC(MONTHS_BETWEEN(SYSDATE, :NEW.birth_date) / 12) < 10) THEN
    RAISE_APPLICATION_ERROR(-20001, 'Invalid date_of_birth: the user must be over 10 years old: ');
  END IF;
END;
/

