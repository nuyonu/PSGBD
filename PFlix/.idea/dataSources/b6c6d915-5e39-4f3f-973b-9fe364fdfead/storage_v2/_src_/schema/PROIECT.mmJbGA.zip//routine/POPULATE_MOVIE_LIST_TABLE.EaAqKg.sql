create PROCEDURE populate_movie_list_table AS
    v_total_movies NUMBER DEFAULT 0;
    v_first_id_from_movies NUMBER;
    v_numberFromList NUMBER DEFAULT 0;
BEGIN
    SELECT COUNT(*) INTO v_total_movies FROM movies;
    SELECT MIN(movies.id) INTO v_first_id_from_movies FROM movies;

    FOR v_list IN (SELECT * FROM lists) LOOP
        v_numberFromList := TRUNC(DBMS_RANDOM.VALUE(5, 50));
        FOR v_index IN 1..v_numberFromList LOOP
            INSERT INTO movie_list (id_list, id_movie) 
            VALUES(v_list.id, TRUNC(DBMS_RANDOM.VALUE(v_first_id_from_movies, v_first_id_from_movies + v_total_movies)));
        END LOOP;
    END LOOP;
END;
/

